from app.calculator import plus, minus, umn, delit, stepen

a = float(input("Первое число: "))
op = input("Действие (+, -, *, /, **): ")
b = float(input("Второе число: "))

if op == "+":
    print("Результат:", plus(a, b))
elif op == "-":
    print("Результат:", minus(a, b))
elif op == "*":
    print("Результат:", umn(a, b))
elif op == "/":
    print("Результат:", delit(a, b))
elif op == "**":
    print("Результат:", stepen(a, b))
else:
    print("Неизвестное действие")
