def plus(a, b):
    return a + b

def minus(a, b):
    return a - b

def umn(a, b):
    return a * b

def delit(a, b):
    if b == 0:
        raise ValueError("На ноль делить нельзя")
    return a / b

def stepen(a, b):
    return a ** b
