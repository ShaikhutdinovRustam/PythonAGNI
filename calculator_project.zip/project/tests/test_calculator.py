import unittest
from app.calculator import plus, minus, umn, delit, stepen

class TestCalc(unittest.TestCase):
    def test_plus(self):
        self.assertEqual(plus(2, 3), 5)

    def test_minus(self):
        self.assertEqual(minus(5, 2), 3)

    def test_umn(self):
        self.assertEqual(umn(3, 4), 12)

    def test_delit(self):
        self.assertEqual(delit(10, 2), 5)
        with self.assertRaises(ValueError):
            delit(5, 0)

    def test_stepen(self):
        self.assertEqual(stepen(2, 3), 8)

if __name__ == "__main__":
    unittest.main()
